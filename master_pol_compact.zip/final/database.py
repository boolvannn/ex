# -*- coding: utf-8 -*-
# Модуль подключения к PostgreSQL
import psycopg2
from psycopg2.extras import RealDictCursor

DB = {
    "host": "localhost", "port": 5432,
    "database": "master_pol", "user": "postgres", "password": "postgres",
    "options": "-c client_encoding=UTF8"   # фикс кодировки
}

def get_conn():
    conn = psycopg2.connect(**DB, cursor_factory=RealDictCursor)
    conn.set_client_encoding("UTF8")
    return conn

def fetch_all(sql, params=()):
    conn = get_conn()
    cur  = conn.cursor()
    cur.execute(sql, params)
    rows = cur.fetchall()
    cur.close(); conn.close()
    return rows

def execute(sql, params=()):
    conn = get_conn()
    cur  = conn.cursor()
    cur.execute(sql, params)
    conn.commit()
    cur.close(); conn.close()
