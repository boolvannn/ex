# -*- coding: utf-8 -*-
# Приложение «Мастер пол» | Запуск: python main.py

import tkinter as tk
from tkinter import ttk, messagebox
from database import fetch_all, execute

WHITE = "#FFFFFF"; BEIGE = "#F4E8D3"; GREEN = "#67BA80"; FONT = "Segoe UI"


def get_discount(partner_id):
    """Скидка по объёму продаж партнёра."""
    total = int(fetch_all(
        "SELECT COALESCE(SUM(quantity),0) AS t FROM partner_products WHERE partner_id=%s",
        (partner_id,)
    )[0]["t"])
    return 15 if total >= 300_000 else 10 if total >= 50_000 else 5 if total >= 10_000 else 0


# ══════ ГЛАВНОЕ ОКНО — список партнёров ══════════════════════════
class PartnersListWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Мастер пол — Партнёры")
        self.geometry("900x500")
        self.configure(bg=WHITE)
        try: self.iconbitmap("logo.ico")
        except: pass
        self._build()
        self.load_partners()

    def _build(self):
        # Шапка
        top = tk.Frame(self, bg=GREEN, pady=8)
        top.pack(fill="x")
        try:
            from PIL import Image, ImageTk
            img = Image.open("logo.png").resize((40, 40))
            self._logo = ImageTk.PhotoImage(img)
            tk.Label(top, image=self._logo, bg=GREEN).pack(side="left", padx=12)
        except: pass
        tk.Label(top, text="Партнёры", font=(FONT,16,"bold"), bg=GREEN, fg=WHITE).pack(side="left")
        tk.Button(top, text="+ Добавить", font=(FONT,10), bg=WHITE, fg=GREEN,
                  relief="flat", padx=10, command=self.open_add_form).pack(side="right", padx=12)

        # Таблица
        frame = tk.Frame(self, bg=WHITE)
        frame.pack(fill="both", expand=True, padx=16, pady=10)
        cols = ("type","name","director","phone","rating","discount")
        self.table = ttk.Treeview(frame, columns=cols, show="headings", height=18)
        for col, label, w in [("type","Тип",80),("name","Партнёр",220),
                               ("director","Директор",180),("phone","Телефон",130),
                               ("rating","Рейтинг",70),("discount","Скидка",70)]:
            self.table.heading(col, text=label)
            self.table.column(col, width=w, anchor="w")
        s = ttk.Style()
        s.configure("Treeview", font=(FONT,10), rowheight=28)
        s.configure("Treeview.Heading", font=(FONT,10,"bold"), background=BEIGE)
        sb = ttk.Scrollbar(frame, orient="vertical", command=self.table.yview)
        self.table.configure(yscrollcommand=sb.set)
        self.table.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.table.bind("<Double-1>", self.open_edit_form)
        tk.Label(self, text="Двойной клик — редактировать", font=(FONT,9), bg=WHITE, fg="gray").pack(pady=(0,6))

    def load_partners(self):
        for r in self.table.get_children(): self.table.delete(r)
        for p in fetch_all("SELECT * FROM partners ORDER BY name"):
            self.table.insert("", "end", iid=p["id"], values=(
                p["partner_type"], p["name"], p["director"],
                p["phone"], p["rating"], f"{get_discount(p['id'])}%"))

    def open_add_form(self):  PartnerFormWindow(self)
    def open_edit_form(self, e):
        sel = self.table.focus()
        if sel: PartnerFormWindow(self, int(sel))


# ══════ ФОРМА добавления / редактирования партнёра ═══════════════
class PartnerFormWindow(tk.Toplevel):
    TYPES = ["ЗАО","ООО","ПАО","ОАО","ИП"]

    def __init__(self, parent, partner_id=None):
        super().__init__(parent)
        self.parent = parent; self.partner_id = partner_id
        mode = "Редактировать партнёра" if partner_id else "Добавить партнёра"
        self.title(f"Мастер пол — {mode}")
        self.geometry("480x460"); self.resizable(False, False)
        self.configure(bg=WHITE); self.grab_set()
        self._build()
        if partner_id: self._load()

    def _build(self):
        tk.Label(self, text=self.title().split("—")[1].strip(),
                 font=(FONT,14,"bold"), bg=WHITE, fg="#333").pack(pady=(14,4))

        form = tk.Frame(self, bg=BEIGE, padx=20, pady=16)
        form.pack(fill="both", expand=True, padx=20, pady=8)
        form.columnconfigure(1, weight=1)

        self.v_type = tk.StringVar(); self.v_name = tk.StringVar()
        self.v_dir  = tk.StringVar(); self.v_email = tk.StringVar()
        self.v_phone = tk.StringVar(); self.v_addr = tk.StringVar()
        self.v_rating = tk.StringVar(value="0")

        def row(label, var, r, kind="entry"):
            tk.Label(form, text=label, font=(FONT,10), bg=BEIGE, anchor="w").grid(row=r, column=0, sticky="w", pady=4)
            w = (ttk.Combobox(form, textvariable=var, values=self.TYPES, state="readonly", width=28, font=(FONT,10))
                 if kind == "cb" else
                 tk.Entry(form, textvariable=var, width=30, font=(FONT,10), relief="flat", bg=WHITE))
            w.grid(row=r, column=1, sticky="ew", padx=(10,0), pady=4)

        row("Тип партнёра",   self.v_type,  0, "cb")
        row("Наименование *", self.v_name,  1)
        row("Директор",       self.v_dir,   2)
        row("Email",          self.v_email, 3)
        row("Телефон",        self.v_phone, 4)
        row("Адрес",          self.v_addr,  5)

        tk.Label(form, text="Рейтинг", font=(FONT,10), bg=BEIGE, anchor="w").grid(row=6, column=0, sticky="w", pady=4)
        tk.Spinbox(form, textvariable=self.v_rating, from_=0, to=10, width=6,
                   font=(FONT,10), relief="flat", bg=WHITE).grid(row=6, column=1, sticky="w", padx=(10,0))

        btns = tk.Frame(self, bg=WHITE); btns.pack(fill="x", padx=20, pady=10)
        tk.Button(btns, text="Сохранить", font=(FONT,10,"bold"), bg=GREEN, fg=WHITE,
                  relief="flat", padx=16, pady=6, command=self.save).pack(side="right")
        tk.Button(btns, text="Отмена", font=(FONT,10), bg=BEIGE, relief="flat",
                  padx=12, pady=6, command=self.destroy).pack(side="right", padx=(0,8))
        if self.partner_id:
            tk.Button(btns, text="Удалить", font=(FONT,10), bg="#E53935", fg=WHITE,
                      relief="flat", padx=12, pady=6, command=self.delete).pack(side="left")

    def _load(self):
        p = fetch_all("SELECT * FROM partners WHERE id=%s", (self.partner_id,))
        if not p: return
        p = p[0]
        self.v_type.set(p["partner_type"] or ""); self.v_name.set(p["name"] or "")
        self.v_dir.set(p["director"] or "");      self.v_email.set(p["email"] or "")
        self.v_phone.set(p["phone"] or "");        self.v_addr.set(p["legal_address"] or "")
        self.v_rating.set(str(p["rating"] or 0))

    def save(self):
        name = self.v_name.get().strip()
        if not name:
            messagebox.showwarning("Ошибка", "Поле «Наименование» обязательно.", parent=self); return
        try:
            rating = int(self.v_rating.get())
            assert rating >= 0
        except:
            messagebox.showwarning("Ошибка", "Рейтинг — целое неотрицательное число.", parent=self); return

        vals = (self.v_type.get(), name, self.v_dir.get(),
                self.v_email.get(), self.v_phone.get(), self.v_addr.get(), rating)
        if self.partner_id:
            execute("UPDATE partners SET partner_type=%s,name=%s,director=%s,"
                    "email=%s,phone=%s,legal_address=%s,rating=%s WHERE id=%s", vals+(self.partner_id,))
            messagebox.showinfo("Готово", "Данные обновлены.", parent=self)
        else:
            execute("INSERT INTO partners(partner_type,name,director,email,phone,legal_address,rating)"
                    " VALUES(%s,%s,%s,%s,%s,%s,%s)", vals)
            messagebox.showinfo("Готово", "Партнёр добавлен.", parent=self)
        self.parent.load_partners(); self.destroy()

    def delete(self):
        if not messagebox.askyesno("Удаление", "Удалить партнёра? Действие необратимо.", parent=self): return
        execute("DELETE FROM partner_products WHERE partner_id=%s", (self.partner_id,))
        execute("DELETE FROM partners WHERE id=%s", (self.partner_id,))
        messagebox.showinfo("Удалено", "Партнёр удалён.", parent=self)
        self.parent.load_partners(); self.destroy()


# ══════ ТОЧКА ВХОДА ══════════════════════════════════════════════
if __name__ == "__main__":
    try:
        PartnersListWindow().mainloop()
    except Exception as e:
        r = tk.Tk(); r.withdraw()
        messagebox.showerror("Ошибка БД", f"Нет подключения к PostgreSQL:\n{e}\n\nПроверьте database.py")
        r.destroy()
