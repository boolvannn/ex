# Мастер пол — Система управления партнёрами

Десктопное приложение на Python (tkinter) с базой данных PostgreSQL.

## Требования

- Python 3.10+
- PostgreSQL 14+
- PyCharm (рекомендуется)

## Установка

### 1. Создание базы данных PostgreSQL

Откройте pgAdmin или psql и выполните:

```sql
CREATE DATABASE master_pol;
```

### 2. Настройка подключения

Откройте файл `db/database.py` и измените параметры:

```python
DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "database": "master_pol",
    "user": "postgres",       # ← ваш пользователь
    "password": "postgres"    # ← ваш пароль
}
```

### 3. Установка зависимостей

В PyCharm откройте терминал и выполните:

```bash
pip install -r requirements.txt
```

Или в PyCharm: **File → Settings → Project → Python Interpreter → + → установить пакеты из requirements.txt**

### 4. Импорт данных

Скопируйте файлы xlsx в папку `data/` рядом с `main.py`:

```
master_pol/
  data/
    Product_type_import.xlsx
    Material_type_import.xlsx
    Partners_import.xlsx
    Partner_products_import.xlsx
    Products_import.xlsx
```

### 5. Запуск

```bash
python main.py
```

Или в PyCharm: правая кнопка на `main.py` → **Run 'main'**

При первом запуске таблицы БД создаются автоматически.  
Для импорта данных нажмите кнопку **«⬆ Импорт данных»** в нижней части бокового меню.

---

## Структура проекта

```
master_pol/
├── main.py                    # Точка входа, главное окно
├── requirements.txt
├── resources/
│   ├── logo.png               # Логотип
│   └── logo.ico               # Иконка
├── db/
│   └── database.py            # Подключение и инициализация БД
├── ui/
│   ├── partners_window.py     # Список партнёров
│   ├── partner_form.py        # Форма добавления/редактирования партнёра
│   ├── products_window.py     # Список продуктов
│   ├── product_form.py        # Форма продукта
│   ├── partner_products_window.py  # История продаж
│   └── references_window.py   # Справочники (типы продукции, материалов)
└── utils/
    ├── discount.py            # Расчёт скидок партнёров
    └── importer.py            # Импорт данных из xlsx
```

## Логика расчёта скидок

| Объём продаж (шт.) | Скидка |
|--------------------|--------|
| < 10 000           | 0%     |
| 10 000 – 49 999    | 5%     |
| 50 000 – 299 999   | 10%    |
| ≥ 300 000          | 15%    |

Скидка отображается в списке партнёров и в карточке партнёра.
