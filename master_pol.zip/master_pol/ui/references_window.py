import tkinter as tk
from tkinter import ttk, messagebox
from db.database import get_connection

COLORS = {
    "bg": "#F4F4F4",
    "sidebar": "#2E7D5E",
    "card": "#FFFFFF",
    "text": "#333333",
    "subtext": "#777777",
    "border": "#DDDDDD",
}


class ReferencesWindow(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=COLORS["bg"])
        self._build()

    def _build(self):
        tk.Label(self, text="Справочники", font=("Segoe UI", 18, "bold"),
                 bg=COLORS["bg"], fg=COLORS["text"],
                 padx=20, pady=12).pack(anchor="w")

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=20, pady=(0, 20))

        pt_frame = tk.Frame(nb, bg=COLORS["bg"])
        nb.add(pt_frame, text="  Типы продукции  ")
        ProductTypesTab(pt_frame).pack(fill="both", expand=True)

        mt_frame = tk.Frame(nb, bg=COLORS["bg"])
        nb.add(mt_frame, text="  Типы материала  ")
        MaterialTypesTab(mt_frame).pack(fill="both", expand=True)


class ProductTypesTab(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=COLORS["bg"])
        self._build()
        self.load()

    def _build(self):
        top = tk.Frame(self, bg=COLORS["bg"], pady=8)
        top.pack(fill="x")
        tk.Button(top, text="+ Добавить", bg=COLORS["sidebar"], fg="white",
                  font=("Segoe UI", 10), relief="flat", padx=12, pady=5,
                  cursor="hand2", command=self.add).pack(side="right", padx=4)

        cols = ("name", "coefficient")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", selectmode="browse")
        self.tree.heading("name", text="Тип продукции")
        self.tree.heading("coefficient", text="Коэффициент")
        self.tree.column("name", width=280)
        self.tree.column("coefficient", width=140, anchor="center")

        style = ttk.Style()
        style.configure("Treeview", font=("Segoe UI", 10), rowheight=30,
                         background="white", fieldbackground="white")

        scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.tree.bind("<Double-1>", self.edit)

    def load(self):
        for r in self.tree.get_children():
            self.tree.delete(r)
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT id, name, coefficient FROM product_types ORDER BY name")
        for r in cur.fetchall():
            self.tree.insert("", "end", iid=r["id"],
                             values=(r["name"], r["coefficient"]))
        cur.close()
        conn.close()

    def add(self):
        RefItemDialog(self.master, "Тип продукции", "Коэффициент",
                      table="product_types",
                      col1="name", col2="coefficient",
                      on_save=self.load)

    def edit(self, event):
        item = self.tree.focus()
        if item:
            vals = self.tree.item(item)["values"]
            RefItemDialog(self.master, "Тип продукции", "Коэффициент",
                          table="product_types",
                          col1="name", col2="coefficient",
                          record_id=int(item),
                          initial=(str(vals[0]), str(vals[1])),
                          on_save=self.load)


class MaterialTypesTab(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=COLORS["bg"])
        self._build()
        self.load()

    def _build(self):
        top = tk.Frame(self, bg=COLORS["bg"], pady=8)
        top.pack(fill="x")
        tk.Button(top, text="+ Добавить", bg=COLORS["sidebar"], fg="white",
                  font=("Segoe UI", 10), relief="flat", padx=12, pady=5,
                  cursor="hand2", command=self.add).pack(side="right", padx=4)

        cols = ("name", "defect_percent")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", selectmode="browse")
        self.tree.heading("name", text="Тип материала")
        self.tree.heading("defect_percent", text="% брака")
        self.tree.column("name", width=280)
        self.tree.column("defect_percent", width=140, anchor="center")

        style = ttk.Style()
        style.configure("Treeview", font=("Segoe UI", 10), rowheight=30,
                         background="white", fieldbackground="white")

        scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        self.tree.bind("<Double-1>", self.edit)

    def load(self):
        for r in self.tree.get_children():
            self.tree.delete(r)
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT id, name, defect_percent FROM material_types ORDER BY name")
        for r in cur.fetchall():
            self.tree.insert("", "end", iid=r["id"],
                             values=(r["name"], f"{float(r['defect_percent']):.4f}"))
        cur.close()
        conn.close()

    def add(self):
        RefItemDialog(self.master, "Тип материала", "% брака (напр. 0.0010)",
                      table="material_types",
                      col1="name", col2="defect_percent",
                      on_save=self.load)

    def edit(self, event):
        item = self.tree.focus()
        if item:
            vals = self.tree.item(item)["values"]
            RefItemDialog(self.master, "Тип материала", "% брака",
                          table="material_types",
                          col1="name", col2="defect_percent",
                          record_id=int(item),
                          initial=(str(vals[0]), str(vals[1])),
                          on_save=self.load)


class RefItemDialog(tk.Toplevel):
    def __init__(self, parent, label1, label2, table, col1, col2,
                 record_id=None, initial=None, on_save=None):
        super().__init__(parent)
        self.table = table
        self.col1 = col1
        self.col2 = col2
        self.record_id = record_id
        self.on_save = on_save
        self.title("Запись")
        self.geometry("380x240")
        self.resizable(False, False)
        self.configure(bg=COLORS["bg"])
        self.grab_set()

        self.v1 = tk.StringVar(value=initial[0] if initial else "")
        self.v2 = tk.StringVar(value=initial[1] if initial else "")

        card = tk.Frame(self, bg=COLORS["card"],
                        highlightbackground=COLORS["border"], highlightthickness=1)
        card.pack(fill="both", expand=True, padx=20, pady=16)
        card.columnconfigure(1, weight=1)

        for i, (lbl, var) in enumerate([(label1, self.v1), (label2, self.v2)]):
            tk.Label(card, text=lbl, bg=COLORS["card"],
                     font=("Segoe UI", 10), fg=COLORS["subtext"],
                     anchor="w").grid(row=i, column=0, sticky="w",
                                      padx=(16, 8), pady=(14, 0))
            tk.Entry(card, textvariable=var, font=("Segoe UI", 11),
                     relief="flat", bg="#F9F9F9",
                     fg=COLORS["text"]).grid(row=i, column=1, sticky="ew",
                                              padx=(0, 16), pady=(14, 0))

        btn = tk.Frame(self, bg=COLORS["bg"])
        btn.pack(fill="x", padx=20, pady=10)

        if record_id:
            tk.Button(btn, text="Удалить", bg="#E53935", fg="white",
                      font=("Segoe UI", 10), relief="flat", padx=10, pady=5,
                      cursor="hand2", command=self.delete).pack(side="left")

        tk.Button(btn, text="Сохранить", bg=COLORS["sidebar"], fg="white",
                  font=("Segoe UI", 10), relief="flat", padx=12, pady=5,
                  cursor="hand2", command=self.save).pack(side="right")
        tk.Button(btn, text="Отмена", bg=COLORS["border"], fg=COLORS["text"],
                  font=("Segoe UI", 10), relief="flat", padx=12, pady=5,
                  cursor="hand2", command=self.destroy).pack(side="right", padx=(0, 6))

    def save(self):
        v1 = self.v1.get().strip()
        v2 = self.v2.get().strip()
        if not v1 or not v2:
            messagebox.showwarning("Ошибка", "Заполните оба поля", parent=self)
            return
        conn = get_connection()
        cur = conn.cursor()
        try:
            if self.record_id:
                cur.execute(
                    f"UPDATE {self.table} SET {self.col1}=%s, {self.col2}=%s WHERE id=%s",
                    (v1, v2, self.record_id))
            else:
                cur.execute(
                    f"INSERT INTO {self.table} ({self.col1}, {self.col2}) VALUES (%s, %s)",
                    (v1, v2))
            conn.commit()
        except Exception as e:
            messagebox.showerror("Ошибка", str(e), parent=self)
            return
        finally:
            cur.close()
            conn.close()
        if self.on_save:
            self.on_save()
        self.destroy()

    def delete(self):
        if not messagebox.askyesno("Удаление", "Удалить запись?", parent=self):
            return
        conn = get_connection()
        cur = conn.cursor()
        cur.execute(f"DELETE FROM {self.table} WHERE id = %s", (self.record_id,))
        conn.commit()
        cur.close()
        conn.close()
        if self.on_save:
            self.on_save()
        self.destroy()
