import tkinter as tk
from tkinter import ttk, messagebox
from db.database import get_connection
import datetime

COLORS = {
    "bg": "#F4F4F4",
    "sidebar": "#2E7D5E",
    "card": "#FFFFFF",
    "text": "#333333",
    "subtext": "#777777",
    "border": "#DDDDDD",
}


class PartnerProductsWindow(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=COLORS["bg"])
        self._build_ui()
        self.load_data()

    def _build_ui(self):
        top = tk.Frame(self, bg=COLORS["card"], pady=12, padx=20)
        top.pack(fill="x")

        tk.Label(top, text="История продаж партнёров", font=("Segoe UI", 18, "bold"),
                 bg=COLORS["card"], fg=COLORS["text"]).pack(side="left")

        tk.Button(top, text="+ Добавить запись",
                  bg=COLORS["sidebar"], fg="white",
                  font=("Segoe UI", 10, "bold"),
                  relief="flat", padx=14, pady=6,
                  cursor="hand2",
                  command=self.add_record).pack(side="right")

        # Filter
        filter_frame = tk.Frame(self, bg=COLORS["bg"], pady=8, padx=20)
        filter_frame.pack(fill="x")

        tk.Label(filter_frame, text="Партнёр:", bg=COLORS["bg"],
                 font=("Segoe UI", 10), fg=COLORS["subtext"]).pack(side="left")

        self.filter_var = tk.StringVar(value="Все")
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT name FROM partners ORDER BY name")
        partners = ["Все"] + [r["name"] for r in cur.fetchall()]
        cur.close()
        conn.close()

        cb = ttk.Combobox(filter_frame, textvariable=self.filter_var,
                          values=partners, state="readonly",
                          font=("Segoe UI", 10), width=28)
        cb.pack(side="left", padx=(8, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self.load_data())

        # Table
        table_frame = tk.Frame(self, bg=COLORS["bg"], padx=20, pady=4)
        table_frame.pack(fill="both", expand=True)

        cols = ("partner", "product", "quantity", "sale_date")
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings",
                                  selectmode="browse")

        headers = {
            "partner": ("Партнёр", 200),
            "product": ("Продукция", 380),
            "quantity": ("Количество", 110),
            "sale_date": ("Дата продажи", 120),
        }

        for col, (label, width) in headers.items():
            self.tree.heading(col, text=label)
            self.tree.column(col, width=width, anchor="w")

        style = ttk.Style()
        style.configure("Treeview", font=("Segoe UI", 10), rowheight=32,
                         background="white", fieldbackground="white")
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))

        scrollbar = ttk.Scrollbar(table_frame, orient="vertical",
                                   command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.tree.bind("<Double-1>", self.on_double_click)

        self.status_var = tk.StringVar()
        tk.Label(self, textvariable=self.status_var, bg=COLORS["bg"],
                 fg=COLORS["subtext"], font=("Segoe UI", 9),
                 anchor="w", padx=20).pack(fill="x", pady=(2, 6))

    def load_data(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        partner_filter = self.filter_var.get()
        conn = get_connection()
        cur = conn.cursor()

        if partner_filter == "Все":
            cur.execute("""
                SELECT pp.id, pa.name as partner, pr.name as product,
                       pp.quantity, pp.sale_date
                FROM partner_products pp
                JOIN partners pa ON pp.partner_id = pa.id
                JOIN products pr ON pp.product_id = pr.id
                ORDER BY pp.sale_date DESC
            """)
        else:
            cur.execute("""
                SELECT pp.id, pa.name as partner, pr.name as product,
                       pp.quantity, pp.sale_date
                FROM partner_products pp
                JOIN partners pa ON pp.partner_id = pa.id
                JOIN products pr ON pp.product_id = pr.id
                WHERE pa.name = %s
                ORDER BY pp.sale_date DESC
            """, (partner_filter,))

        rows = cur.fetchall()
        cur.close()
        conn.close()

        total_qty = 0
        for r in rows:
            date_str = r["sale_date"].strftime("%d.%m.%Y") if r["sale_date"] else "—"
            self.tree.insert("", "end", iid=r["id"], values=(
                r["partner"], r["product"],
                f"{r['quantity']:,}", date_str
            ))
            total_qty += r["quantity"] or 0

        self.status_var.set(f"Записей: {len(rows)}  |  Итого: {total_qty:,} шт.")

    def add_record(self):
        SaleForm(self.master, on_save=self.load_data)

    def on_double_click(self, event):
        item = self.tree.focus()
        if item:
            SaleForm(self.master, record_id=int(item), on_save=self.load_data)


class SaleForm(tk.Toplevel):
    def __init__(self, parent, record_id=None, on_save=None):
        super().__init__(parent)
        self.record_id = record_id
        self.on_save = on_save
        self.title("Запись продажи")
        self.geometry("500x360")
        self.resizable(False, False)
        self.configure(bg=COLORS["bg"])
        self.grab_set()
        self._load_refs()
        self._build()
        if record_id:
            self._load()

    def _load_refs(self):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT id, name FROM partners ORDER BY name")
        self.partners = {r["name"]: r["id"] for r in cur.fetchall()}
        cur.execute("SELECT id, name FROM products ORDER BY name")
        self.products = {r["name"]: r["id"] for r in cur.fetchall()}
        cur.close()
        conn.close()

    def _build(self):
        tk.Label(self, text="Запись о продаже", font=("Segoe UI", 14, "bold"),
                 bg=COLORS["bg"], fg=COLORS["text"]).pack(pady=(16, 8), padx=20, anchor="w")

        card = tk.Frame(self, bg=COLORS["card"],
                        highlightbackground=COLORS["border"], highlightthickness=1)
        card.pack(fill="both", expand=True, padx=20, pady=(0, 8))
        card.columnconfigure(1, weight=1)

        self.v_partner = tk.StringVar()
        self.v_product = tk.StringVar()
        self.v_qty = tk.StringVar()
        self.v_date = tk.StringVar(value=datetime.date.today().strftime("%d.%m.%Y"))

        tk.Label(card, text="Партнёр *", bg=COLORS["card"],
                 font=("Segoe UI", 10), fg=COLORS["subtext"],
                 anchor="w").grid(row=0, column=0, sticky="w", padx=(20, 8), pady=(16, 0))
        ttk.Combobox(card, textvariable=self.v_partner,
                     values=list(self.partners.keys()),
                     font=("Segoe UI", 10), state="readonly",
                     width=34).grid(row=0, column=1, sticky="ew",
                                    padx=(0, 20), pady=(16, 0))

        tk.Label(card, text="Продукция *", bg=COLORS["card"],
                 font=("Segoe UI", 10), fg=COLORS["subtext"],
                 anchor="w").grid(row=1, column=0, sticky="w", padx=(20, 8), pady=(12, 0))
        ttk.Combobox(card, textvariable=self.v_product,
                     values=list(self.products.keys()),
                     font=("Segoe UI", 10), state="readonly",
                     width=34).grid(row=1, column=1, sticky="ew",
                                    padx=(0, 20), pady=(12, 0))

        for label, row, var in [("Количество *", 2, self.v_qty),
                                 ("Дата (дд.мм.гггг)", 3, self.v_date)]:
            tk.Label(card, text=label, bg=COLORS["card"],
                     font=("Segoe UI", 10), fg=COLORS["subtext"],
                     anchor="w").grid(row=row, column=0, sticky="w",
                                      padx=(20, 8), pady=(12, 0))
            tk.Entry(card, textvariable=var, font=("Segoe UI", 11),
                     relief="flat", bg="#F9F9F9",
                     fg=COLORS["text"]).grid(row=row, column=1, sticky="ew",
                                              padx=(0, 20), pady=(12, 0))

        btn_frame = tk.Frame(self, bg=COLORS["bg"])
        btn_frame.pack(fill="x", padx=20, pady=12)

        if self.record_id:
            tk.Button(btn_frame, text="Удалить", bg="#E53935", fg="white",
                      font=("Segoe UI", 10), relief="flat", padx=12, pady=6,
                      cursor="hand2", command=self.delete).pack(side="left")

        tk.Button(btn_frame, text="Сохранить", bg=COLORS["sidebar"], fg="white",
                  font=("Segoe UI", 10, "bold"), relief="flat", padx=14, pady=6,
                  cursor="hand2", command=self.save).pack(side="right")
        tk.Button(btn_frame, text="Отмена", bg=COLORS["border"], fg=COLORS["text"],
                  font=("Segoe UI", 10), relief="flat", padx=14, pady=6,
                  cursor="hand2", command=self.destroy).pack(side="right", padx=(0, 8))

    def _load(self):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT pp.*, pa.name as pname, pr.name as prname
            FROM partner_products pp
            JOIN partners pa ON pp.partner_id = pa.id
            JOIN products pr ON pp.product_id = pr.id
            WHERE pp.id = %s
        """, (self.record_id,))
        r = cur.fetchone()
        cur.close()
        conn.close()
        if r:
            self.v_partner.set(r["pname"])
            self.v_product.set(r["prname"])
            self.v_qty.set(str(r["quantity"]))
            if r["sale_date"]:
                self.v_date.set(r["sale_date"].strftime("%d.%m.%Y"))

    def save(self):
        partner = self.v_partner.get()
        product = self.v_product.get()
        if not partner or partner not in self.partners:
            messagebox.showwarning("Ошибка", "Выберите партнёра", parent=self)
            return
        if not product or product not in self.products:
            messagebox.showwarning("Ошибка", "Выберите продукт", parent=self)
            return
        try:
            qty = int(self.v_qty.get())
            date = datetime.datetime.strptime(self.v_date.get(), "%d.%m.%Y").date()
        except ValueError:
            messagebox.showwarning("Ошибка",
                                   "Количество — целое число, дата — дд.мм.гггг",
                                   parent=self)
            return

        conn = get_connection()
        cur = conn.cursor()
        try:
            if self.record_id:
                cur.execute("""
                    UPDATE partner_products
                    SET partner_id=%s, product_id=%s, quantity=%s, sale_date=%s
                    WHERE id=%s
                """, (self.partners[partner], self.products[product],
                      qty, date, self.record_id))
            else:
                cur.execute("""
                    INSERT INTO partner_products (partner_id, product_id, quantity, sale_date)
                    VALUES (%s, %s, %s, %s)
                """, (self.partners[partner], self.products[product], qty, date))
            conn.commit()
        except Exception as e:
            messagebox.showerror("Ошибка БД", str(e), parent=self)
            return
        finally:
            cur.close()
            conn.close()

        if self.on_save:
            self.on_save()
        self.destroy()

    def delete(self):
        if not messagebox.askyesno("Удаление", "Удалить запись?", parent=self):
            return
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM partner_products WHERE id = %s", (self.record_id,))
        conn.commit()
        cur.close()
        conn.close()
        if self.on_save:
            self.on_save()
        self.destroy()
