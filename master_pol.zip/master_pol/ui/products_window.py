import tkinter as tk
from tkinter import ttk, messagebox
from db.database import get_connection

COLORS = {
    "bg": "#F4F4F4",
    "sidebar": "#2E7D5E",
    "card": "#FFFFFF",
    "text": "#333333",
    "subtext": "#777777",
    "border": "#DDDDDD",
}


class ProductsWindow(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=COLORS["bg"])
        self._build_ui()
        self.load_products()

    def _build_ui(self):
        top = tk.Frame(self, bg=COLORS["card"], pady=12, padx=20)
        top.pack(fill="x")

        tk.Label(top, text="Продукция", font=("Segoe UI", 18, "bold"),
                 bg=COLORS["card"], fg=COLORS["text"]).pack(side="left")

        tk.Button(top, text="+ Добавить продукт",
                  bg=COLORS["sidebar"], fg="white",
                  font=("Segoe UI", 10, "bold"),
                  relief="flat", padx=14, pady=6,
                  cursor="hand2",
                  command=self.add_product).pack(side="right")

        # Filter by type
        filter_frame = tk.Frame(self, bg=COLORS["bg"], pady=8, padx=20)
        filter_frame.pack(fill="x")

        tk.Label(filter_frame, text="Тип:", bg=COLORS["bg"],
                 font=("Segoe UI", 10), fg=COLORS["subtext"]).pack(side="left")

        self.filter_var = tk.StringVar(value="Все")
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT name FROM product_types ORDER BY name")
        types = ["Все"] + [r["name"] for r in cur.fetchall()]
        cur.close()
        conn.close()

        cb = ttk.Combobox(filter_frame, textvariable=self.filter_var,
                          values=types, state="readonly",
                          font=("Segoe UI", 10), width=22)
        cb.pack(side="left", padx=(8, 0))
        cb.bind("<<ComboboxSelected>>", lambda e: self.load_products())

        # Table
        table_frame = tk.Frame(self, bg=COLORS["bg"], padx=20, pady=4)
        table_frame.pack(fill="both", expand=True)

        cols = ("article", "type", "name", "min_price")
        self.tree = ttk.Treeview(table_frame, columns=cols, show="headings",
                                  selectmode="browse")

        headers = {
            "article": ("Артикул", 90),
            "type": ("Тип продукции", 160),
            "name": ("Наименование", 400),
            "min_price": ("Мин. цена (₽)", 130),
        }

        for col, (label, width) in headers.items():
            self.tree.heading(col, text=label)
            self.tree.column(col, width=width, anchor="w")

        style = ttk.Style()
        style.configure("Treeview", font=("Segoe UI", 10), rowheight=32,
                         background="white", fieldbackground="white")
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"))

        scrollbar = ttk.Scrollbar(table_frame, orient="vertical",
                                   command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.tree.bind("<Double-1>", self.on_double_click)

        self.status_var = tk.StringVar()
        tk.Label(self, textvariable=self.status_var, bg=COLORS["bg"],
                 fg=COLORS["subtext"], font=("Segoe UI", 9),
                 anchor="w", padx=20).pack(fill="x", pady=(2, 6))

    def load_products(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        conn = get_connection()
        cur = conn.cursor()
        filter_type = self.filter_var.get()
        if filter_type == "Все":
            cur.execute("""
                SELECT p.id, p.article, pt.name as type_name, p.name, p.min_price
                FROM products p
                LEFT JOIN product_types pt ON p.product_type_id = pt.id
                ORDER BY pt.name, p.name
            """)
        else:
            cur.execute("""
                SELECT p.id, p.article, pt.name as type_name, p.name, p.min_price
                FROM products p
                LEFT JOIN product_types pt ON p.product_type_id = pt.id
                WHERE pt.name = %s
                ORDER BY p.name
            """, (filter_type,))

        rows = cur.fetchall()
        cur.close()
        conn.close()

        for r in rows:
            self.tree.insert("", "end", iid=r["id"], values=(
                r["article"], r["type_name"], r["name"],
                f"{r['min_price']:,.2f}" if r["min_price"] else "—"
            ))

        self.status_var.set(f"Продуктов: {len(rows)}")

    def add_product(self):
        from ui.product_form import ProductForm
        ProductForm(self.master, on_save=self.load_products)

    def on_double_click(self, event):
        item = self.tree.focus()
        if item:
            from ui.product_form import ProductForm
            ProductForm(self.master, product_id=int(item), on_save=self.load_products)
