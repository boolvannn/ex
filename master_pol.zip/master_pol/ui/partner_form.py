import tkinter as tk
from tkinter import ttk, messagebox
from db.database import get_connection
from utils.discount import get_partner_discount, get_partner_total_quantity

COLORS = {
    "bg": "#F4F4F4",
    "sidebar": "#2E7D5E",
    "card": "#FFFFFF",
    "accent": "#5CB85C",
    "text": "#333333",
    "subtext": "#777777",
    "border": "#DDDDDD",
}


class PartnerForm(tk.Toplevel):
    def __init__(self, parent, partner_id=None, on_save=None):
        super().__init__(parent)
        self.partner_id = partner_id
        self.on_save = on_save
        self.title("Партнёр" if not partner_id else "Редактировать партнёра")
        self.geometry("560x600")
        self.resizable(False, False)
        self.configure(bg=COLORS["bg"])
        self.grab_set()
        self._build()
        if partner_id:
            self._load()

    def _field(self, parent, label, row, var, width=380):
        tk.Label(parent, text=label, bg=COLORS["card"],
                 font=("Segoe UI", 10), fg=COLORS["subtext"],
                 anchor="w").grid(row=row, column=0, sticky="w",
                                  padx=(20, 8), pady=(8, 0))
        e = tk.Entry(parent, textvariable=var, width=width // 10,
                     font=("Segoe UI", 11), relief="flat",
                     bg="#F9F9F9", fg=COLORS["text"])
        e.grid(row=row, column=1, sticky="ew", padx=(0, 20), pady=(8, 0))
        return e

    def _build(self):
        title = "Добавление партнёра" if not self.partner_id else "Редактирование"
        tk.Label(self, text=title, font=("Segoe UI", 14, "bold"),
                 bg=COLORS["bg"], fg=COLORS["text"]).pack(pady=(16, 8), padx=20, anchor="w")

        card = tk.Frame(self, bg=COLORS["card"], relief="flat",
                        highlightbackground=COLORS["border"], highlightthickness=1)
        card.pack(fill="both", expand=True, padx=20, pady=(0, 8))
        card.columnconfigure(1, weight=1)

        self.v_type = tk.StringVar()
        self.v_name = tk.StringVar()
        self.v_director = tk.StringVar()
        self.v_email = tk.StringVar()
        self.v_phone = tk.StringVar()
        self.v_address = tk.StringVar()
        self.v_inn = tk.StringVar()
        self.v_rating = tk.StringVar(value="0")

        tk.Label(card, text="Тип партнёра", bg=COLORS["card"],
                 font=("Segoe UI", 10), fg=COLORS["subtext"],
                 anchor="w").grid(row=0, column=0, sticky="w", padx=(20, 8), pady=(12, 0))
        type_cb = ttk.Combobox(card, textvariable=self.v_type,
                               values=["ЗАО", "ООО", "ПАО", "ОАО", "ИП"],
                               font=("Segoe UI", 11), state="readonly", width=12)
        type_cb.grid(row=0, column=1, sticky="w", padx=(0, 20), pady=(12, 0))

        self._field(card, "Наименование *", 1, self.v_name)
        self._field(card, "Директор", 2, self.v_director)
        self._field(card, "Email", 3, self.v_email)
        self._field(card, "Телефон", 4, self.v_phone)
        self._field(card, "Юридический адрес", 5, self.v_address)
        self._field(card, "ИНН", 6, self.v_inn)

        tk.Label(card, text="Рейтинг (0-10)", bg=COLORS["card"],
                 font=("Segoe UI", 10), fg=COLORS["subtext"],
                 anchor="w").grid(row=7, column=0, sticky="w", padx=(20, 8), pady=(8, 12))
        tk.Spinbox(card, textvariable=self.v_rating, from_=0, to=10,
                   font=("Segoe UI", 11), width=8, relief="flat",
                   bg="#F9F9F9").grid(row=7, column=1, sticky="w",
                                     padx=(0, 20), pady=(8, 12))

        # Discount info for existing partner
        if self.partner_id:
            self.discount_label = tk.Label(self, text="", bg=COLORS["bg"],
                                           font=("Segoe UI", 11, "bold"),
                                           fg=COLORS["sidebar"])
            self.discount_label.pack(padx=20, anchor="w")

        # Buttons
        btn_frame = tk.Frame(self, bg=COLORS["bg"])
        btn_frame.pack(fill="x", padx=20, pady=12)

        if self.partner_id:
            tk.Button(btn_frame, text="Удалить", bg="#E53935", fg="white",
                      font=("Segoe UI", 10), relief="flat", padx=12, pady=6,
                      cursor="hand2", command=self.delete).pack(side="left")

        tk.Button(btn_frame, text="Сохранить", bg=COLORS["sidebar"], fg="white",
                  font=("Segoe UI", 10, "bold"), relief="flat", padx=14, pady=6,
                  cursor="hand2", command=self.save).pack(side="right")
        tk.Button(btn_frame, text="Отмена", bg=COLORS["border"], fg=COLORS["text"],
                  font=("Segoe UI", 10), relief="flat", padx=14, pady=6,
                  cursor="hand2", command=self.destroy).pack(side="right", padx=(0, 8))

    def _load(self):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM partners WHERE id = %s", (self.partner_id,))
        r = cur.fetchone()
        cur.close()
        conn.close()

        if not r:
            return

        self.v_type.set(r["partner_type"] or "")
        self.v_name.set(r["name"] or "")
        self.v_director.set(r["director"] or "")
        self.v_email.set(r["email"] or "")
        self.v_phone.set(r["phone"] or "")
        self.v_address.set(r["legal_address"] or "")
        self.v_inn.set(r["inn"] or "")
        self.v_rating.set(str(r["rating"] or 0))

        total = get_partner_total_quantity(self.partner_id)
        discount = get_partner_discount(self.partner_id)
        self.discount_label.config(
            text=f"Объём продаж: {total:,} шт  |  Скидка: {discount}%"
        )

    def save(self):
        name = self.v_name.get().strip()
        if not name:
            messagebox.showwarning("Ошибка", "Введите наименование партнёра", parent=self)
            return

        conn = get_connection()
        cur = conn.cursor()
        try:
            if self.partner_id:
                cur.execute("""
                    UPDATE partners SET partner_type=%s, name=%s, director=%s,
                        email=%s, phone=%s, legal_address=%s, inn=%s, rating=%s
                    WHERE id=%s
                """, (self.v_type.get(), name, self.v_director.get(),
                      self.v_email.get(), self.v_phone.get(), self.v_address.get(),
                      self.v_inn.get(), int(self.v_rating.get() or 0), self.partner_id))
            else:
                cur.execute("""
                    INSERT INTO partners (partner_type, name, director, email, phone, legal_address, inn, rating)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """, (self.v_type.get(), name, self.v_director.get(),
                      self.v_email.get(), self.v_phone.get(), self.v_address.get(),
                      self.v_inn.get(), int(self.v_rating.get() or 0)))
            conn.commit()
        except Exception as e:
            messagebox.showerror("Ошибка БД", str(e), parent=self)
            return
        finally:
            cur.close()
            conn.close()

        if self.on_save:
            self.on_save()
        self.destroy()

    def delete(self):
        if not messagebox.askyesno("Удаление",
                                   "Удалить партнёра? Все связанные продажи тоже будут удалены.",
                                   parent=self):
            return
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM partner_products WHERE partner_id = %s", (self.partner_id,))
        cur.execute("DELETE FROM partners WHERE id = %s", (self.partner_id,))
        conn.commit()
        cur.close()
        conn.close()
        if self.on_save:
            self.on_save()
        self.destroy()
