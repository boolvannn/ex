import tkinter as tk
from tkinter import ttk, messagebox
from db.database import get_connection
from utils.discount import get_partner_discount
from ui.partner_form import PartnerForm


COLORS = {
    "bg": "#F4F4F4",
    "sidebar": "#2E7D5E",
    "card": "#FFFFFF",
    "accent": "#5CB85C",
    "text": "#333333",
    "subtext": "#777777",
    "border": "#DDDDDD",
    "header_bg": "#FFFFFF",
}


class PartnersWindow(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg=COLORS["bg"])
        self.parent = parent
        self._build_ui()
        self.load_partners()

    def _build_ui(self):
        # Top bar
        top = tk.Frame(self, bg=COLORS["header_bg"], pady=12, padx=20)
        top.pack(fill="x")

        tk.Label(top, text="Партнёры", font=("Segoe UI", 18, "bold"),
                 bg=COLORS["header_bg"], fg=COLORS["text"]).pack(side="left")

        btn_frame = tk.Frame(top, bg=COLORS["header_bg"])
        btn_frame.pack(side="right")

        tk.Button(btn_frame, text="+ Добавить партнёра",
                  bg=COLORS["sidebar"], fg="white",
                  font=("Segoe UI", 10, "bold"),
                  relief="flat", padx=14, pady=6,
                  cursor="hand2",
                  command=self.add_partner).pack(side="right", padx=(8, 0))

        # Search
        search_frame = tk.Frame(self, bg=COLORS["bg"], pady=8, padx=20)
        search_frame.pack(fill="x")

        self.search_var = tk.StringVar()
        self.search_var.trace("w", lambda *a: self.load_partners())
        search_entry = tk.Entry(search_frame, textvariable=self.search_var,
                                font=("Segoe UI", 11), relief="flat",
                                bg="white", fg=COLORS["text"])
        search_entry.pack(side="left", fill="x", expand=True, ipady=6, ipadx=10)

        search_frame.config(highlightbackground=COLORS["border"],
                            highlightthickness=1)

        tk.Label(search_frame, text="🔍", bg="white",
                 font=("Segoe UI", 12)).pack(side="left")

        # Table
        table_frame = tk.Frame(self, bg=COLORS["bg"], padx=20, pady=4)
        table_frame.pack(fill="both", expand=True)

        columns = ("type", "name", "director", "phone", "rating", "discount")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings",
                                 selectmode="browse")

        headers = {
            "type": ("Тип", 80),
            "name": ("Наименование", 220),
            "director": ("Директор", 200),
            "phone": ("Телефон", 140),
            "rating": ("Рейтинг", 70),
            "discount": ("Скидка %", 80),
        }

        for col, (label, width) in headers.items():
            self.tree.heading(col, text=label)
            self.tree.column(col, width=width, anchor="w")

        style = ttk.Style()
        style.configure("Treeview", font=("Segoe UI", 10), rowheight=32,
                         background="white", fieldbackground="white")
        style.configure("Treeview.Heading", font=("Segoe UI", 10, "bold"),
                         background=COLORS["border"])
        style.map("Treeview", background=[("selected", "#D6EFE1")])

        scrollbar = ttk.Scrollbar(table_frame, orient="vertical",
                                   command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)

        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        self.tree.bind("<Double-1>", self.on_double_click)

        # Status bar
        self.status_var = tk.StringVar(value="")
        tk.Label(self, textvariable=self.status_var, bg=COLORS["bg"],
                 fg=COLORS["subtext"], font=("Segoe UI", 9),
                 anchor="w", padx=20).pack(fill="x", pady=(2, 6))

    def load_partners(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        search = self.search_var.get().strip().lower()
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT id, partner_type, name, director, phone, rating
            FROM partners
            ORDER BY name
        """)
        rows = cur.fetchall()
        cur.close()
        conn.close()

        count = 0
        for r in rows:
            if search and search not in r["name"].lower() \
                    and search not in (r["director"] or "").lower():
                continue
            discount = get_partner_discount(r["id"])
            self.tree.insert("", "end", iid=r["id"], values=(
                r["partner_type"], r["name"], r["director"],
                r["phone"], r["rating"], f"{discount}%"
            ))
            count += 1

        self.status_var.set(f"Найдено партнёров: {count}")

    def add_partner(self):
        PartnerForm(self.parent, on_save=self.load_partners)

    def on_double_click(self, event):
        item = self.tree.focus()
        if item:
            PartnerForm(self.parent, partner_id=int(item), on_save=self.load_partners)
