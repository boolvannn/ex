import tkinter as tk
from tkinter import ttk, messagebox
from db.database import get_connection

COLORS = {
    "bg": "#F4F4F4",
    "sidebar": "#2E7D5E",
    "card": "#FFFFFF",
    "text": "#333333",
    "subtext": "#777777",
    "border": "#DDDDDD",
}


class ProductForm(tk.Toplevel):
    def __init__(self, parent, product_id=None, on_save=None):
        super().__init__(parent)
        self.product_id = product_id
        self.on_save = on_save
        self.title("Продукт")
        self.geometry("500x420")
        self.resizable(False, False)
        self.configure(bg=COLORS["bg"])
        self.grab_set()
        self._load_types()
        self._build()
        if product_id:
            self._load()

    def _load_types(self):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("SELECT id, name FROM product_types ORDER BY name")
        self.product_types = {r["name"]: r["id"] for r in cur.fetchall()}
        cur.close()
        conn.close()

    def _build(self):
        title = "Добавление продукта" if not self.product_id else "Редактирование продукта"
        tk.Label(self, text=title, font=("Segoe UI", 14, "bold"),
                 bg=COLORS["bg"], fg=COLORS["text"]).pack(pady=(16, 8), padx=20, anchor="w")

        card = tk.Frame(self, bg=COLORS["card"],
                        highlightbackground=COLORS["border"], highlightthickness=1)
        card.pack(fill="both", expand=True, padx=20, pady=(0, 8))
        card.columnconfigure(1, weight=1)

        self.v_type = tk.StringVar()
        self.v_name = tk.StringVar()
        self.v_article = tk.StringVar()
        self.v_price = tk.StringVar()

        tk.Label(card, text="Тип продукции *", bg=COLORS["card"],
                 font=("Segoe UI", 10), fg=COLORS["subtext"],
                 anchor="w").grid(row=0, column=0, sticky="w", padx=(20, 8), pady=(16, 0))
        ttk.Combobox(card, textvariable=self.v_type,
                     values=list(self.product_types.keys()),
                     font=("Segoe UI", 11), state="readonly",
                     width=28).grid(row=0, column=1, sticky="ew",
                                    padx=(0, 20), pady=(16, 0))

        fields = [
            ("Наименование *", 1, self.v_name),
            ("Артикул", 2, self.v_article),
            ("Мин. цена для партнёра (₽)", 3, self.v_price),
        ]

        for label, row, var in fields:
            tk.Label(card, text=label, bg=COLORS["card"],
                     font=("Segoe UI", 10), fg=COLORS["subtext"],
                     anchor="w").grid(row=row, column=0, sticky="w",
                                      padx=(20, 8), pady=(12, 0))
            tk.Entry(card, textvariable=var, font=("Segoe UI", 11),
                     relief="flat", bg="#F9F9F9",
                     fg=COLORS["text"]).grid(row=row, column=1, sticky="ew",
                                              padx=(0, 20), pady=(12, 0))

        btn_frame = tk.Frame(self, bg=COLORS["bg"])
        btn_frame.pack(fill="x", padx=20, pady=12)

        if self.product_id:
            tk.Button(btn_frame, text="Удалить", bg="#E53935", fg="white",
                      font=("Segoe UI", 10), relief="flat", padx=12, pady=6,
                      cursor="hand2", command=self.delete).pack(side="left")

        tk.Button(btn_frame, text="Сохранить", bg=COLORS["sidebar"], fg="white",
                  font=("Segoe UI", 10, "bold"), relief="flat", padx=14, pady=6,
                  cursor="hand2", command=self.save).pack(side="right")
        tk.Button(btn_frame, text="Отмена", bg=COLORS["border"], fg=COLORS["text"],
                  font=("Segoe UI", 10), relief="flat", padx=14, pady=6,
                  cursor="hand2", command=self.destroy).pack(side="right", padx=(0, 8))

    def _load(self):
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("""
            SELECT p.*, pt.name as type_name
            FROM products p
            LEFT JOIN product_types pt ON p.product_type_id = pt.id
            WHERE p.id = %s
        """, (self.product_id,))
        r = cur.fetchone()
        cur.close()
        conn.close()
        if r:
            self.v_type.set(r["type_name"] or "")
            self.v_name.set(r["name"] or "")
            self.v_article.set(str(r["article"] or ""))
            self.v_price.set(str(r["min_price"] or ""))

    def save(self):
        name = self.v_name.get().strip()
        type_name = self.v_type.get()

        if not name:
            messagebox.showwarning("Ошибка", "Введите наименование", parent=self)
            return
        if not type_name or type_name not in self.product_types:
            messagebox.showwarning("Ошибка", "Выберите тип продукции", parent=self)
            return

        type_id = self.product_types[type_name]
        try:
            article = int(self.v_article.get()) if self.v_article.get() else None
            price = float(self.v_price.get()) if self.v_price.get() else None
        except ValueError:
            messagebox.showwarning("Ошибка", "Артикул — целое число, цена — число", parent=self)
            return

        conn = get_connection()
        cur = conn.cursor()
        try:
            if self.product_id:
                cur.execute("""
                    UPDATE products SET product_type_id=%s, name=%s, article=%s, min_price=%s
                    WHERE id=%s
                """, (type_id, name, article, price, self.product_id))
            else:
                cur.execute("""
                    INSERT INTO products (product_type_id, name, article, min_price)
                    VALUES (%s, %s, %s, %s)
                """, (type_id, name, article, price))
            conn.commit()
        except Exception as e:
            messagebox.showerror("Ошибка БД", str(e), parent=self)
            return
        finally:
            cur.close()
            conn.close()

        if self.on_save:
            self.on_save()
        self.destroy()

    def delete(self):
        if not messagebox.askyesno("Удаление", "Удалить продукт?", parent=self):
            return
        conn = get_connection()
        cur = conn.cursor()
        cur.execute("DELETE FROM partner_products WHERE product_id = %s", (self.product_id,))
        cur.execute("DELETE FROM products WHERE id = %s", (self.product_id,))
        conn.commit()
        cur.close()
        conn.close()
        if self.on_save:
            self.on_save()
        self.destroy()
