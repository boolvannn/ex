import tkinter as tk
from tkinter import messagebox
import sys
import os

# Make project root importable
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from db.database import get_connection, init_db
from ui.partners_window import PartnersWindow
from ui.products_window import ProductsWindow
from ui.partner_products_window import PartnerProductsWindow
from ui.references_window import ReferencesWindow

COLORS = {
    "bg": "#F4F4F4",
    "sidebar": "#2E7D5E",
    "sidebar_hover": "#236347",
    "sidebar_active": "#1B4E38",
    "card": "#FFFFFF",
    "accent": "#5CB85C",
    "text": "#333333",
    "subtext": "#AAAAAA",
    "white": "#FFFFFF",
}

NAV_ITEMS = [
    ("partners", "👥  Партнёры"),
    ("products", "📦  Продукция"),
    ("sales", "📋  История продаж"),
    ("references", "📂  Справочники"),
]


class MainApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Мастер пол — Управление партнёрами")
        self.geometry("1100x680")
        self.minsize(900, 560)
        self.configure(bg=COLORS["bg"])

        # App icon
        try:
            icon_path = os.path.join(os.path.dirname(__file__), "..", "resources", "logo.ico")
            self.iconbitmap(icon_path)
        except Exception:
            pass

        self._check_db()
        self._build_layout()
        self._show_page("partners")

    def _check_db(self):
        try:
            conn = get_connection()
            conn.close()
            init_db()
        except Exception as e:
            messagebox.showerror(
                "Ошибка подключения к БД",
                f"Не удалось подключиться к PostgreSQL:\n{e}\n\n"
                "Проверьте настройки в db/database.py"
            )
            self.destroy()

    def _build_layout(self):
        # Sidebar
        self.sidebar = tk.Frame(self, bg=COLORS["sidebar"], width=220)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        # Logo area
        logo_frame = tk.Frame(self.sidebar, bg=COLORS["sidebar"], pady=20)
        logo_frame.pack(fill="x")

        try:
            from PIL import Image, ImageTk
            img_path = os.path.join(os.path.dirname(__file__), "..", "resources", "logo.png")
            img = Image.open(img_path).resize((56, 56), Image.LANCZOS)
            self._logo_img = ImageTk.PhotoImage(img)
            tk.Label(logo_frame, image=self._logo_img,
                     bg=COLORS["sidebar"]).pack(pady=(8, 4))
        except Exception:
            pass

        tk.Label(logo_frame, text="Мастер пол",
                 font=("Segoe UI", 14, "bold"),
                 bg=COLORS["sidebar"], fg=COLORS["white"]).pack()
        tk.Label(logo_frame, text="Управление партнёрами",
                 font=("Segoe UI", 8),
                 bg=COLORS["sidebar"], fg="#A8D5B5").pack()

        tk.Frame(self.sidebar, bg="#236347", height=1).pack(fill="x", pady=10)

        # Nav buttons
        self.nav_buttons = {}
        for page_id, label in NAV_ITEMS:
            btn = tk.Button(
                self.sidebar, text=label,
                font=("Segoe UI", 11),
                bg=COLORS["sidebar"], fg=COLORS["white"],
                activebackground=COLORS["sidebar_hover"],
                activeforeground=COLORS["white"],
                relief="flat", anchor="w",
                padx=24, pady=10,
                cursor="hand2",
                command=lambda pid=page_id: self._show_page(pid)
            )
            btn.pack(fill="x")
            btn.bind("<Enter>", lambda e, b=btn: self._on_hover(b))
            btn.bind("<Leave>", lambda e, b=btn: self._on_leave(b))
            self.nav_buttons[page_id] = btn

        # Bottom: import data
        tk.Frame(self.sidebar, bg="#236347", height=1).pack(fill="x", pady=10, side="bottom")
        tk.Button(
            self.sidebar, text="⬆  Импорт данных",
            font=("Segoe UI", 10),
            bg=COLORS["sidebar"], fg="#A8D5B5",
            activebackground=COLORS["sidebar_hover"],
            activeforeground=COLORS["white"],
            relief="flat", anchor="w",
            padx=24, pady=8,
            cursor="hand2",
            command=self._import_data
        ).pack(fill="x", side="bottom")

        # Main content area
        self.content = tk.Frame(self, bg=COLORS["bg"])
        self.content.pack(side="left", fill="both", expand=True)

        self.pages = {}

    def _on_hover(self, btn):
        current_page = getattr(self, "_current_page", None)
        page_id = [k for k, v in self.nav_buttons.items() if v == btn]
        if page_id and page_id[0] != current_page:
            btn.configure(bg=COLORS["sidebar_hover"])

    def _on_leave(self, btn):
        current_page = getattr(self, "_current_page", None)
        page_id = [k for k, v in self.nav_buttons.items() if v == btn]
        if page_id and page_id[0] != current_page:
            btn.configure(bg=COLORS["sidebar"])

    def _show_page(self, page_id):
        self._current_page = page_id

        # Update button states
        for pid, btn in self.nav_buttons.items():
            if pid == page_id:
                btn.configure(bg=COLORS["sidebar_active"], fg=COLORS["white"])
            else:
                btn.configure(bg=COLORS["sidebar"], fg=COLORS["white"])

        # Hide existing pages
        for frame in self.content.winfo_children():
            frame.pack_forget()

        # Create or show page
        if page_id not in self.pages:
            page_classes = {
                "partners": PartnersWindow,
                "products": ProductsWindow,
                "sales": PartnerProductsWindow,
                "references": ReferencesWindow,
            }
            cls = page_classes.get(page_id)
            if cls:
                self.pages[page_id] = cls(self.content)

        if page_id in self.pages:
            self.pages[page_id].pack(fill="both", expand=True)

    def _import_data(self):
        if not messagebox.askyesno(
            "Импорт данных",
            "Импортировать данные из папки data/?\n"
            "(Существующие записи будут обновлены)"
        ):
            return
        try:
            from utils.importer import import_all
            import_all(base_path="data")
            messagebox.showinfo("Готово", "Данные успешно импортированы!")
            # Refresh current page
            if self._current_page in self.pages:
                del self.pages[self._current_page]
            self._show_page(self._current_page)
        except Exception as e:
            messagebox.showerror("Ошибка импорта", str(e))


if __name__ == "__main__":
    app = MainApp()
    app.mainloop()
