def calculate_discount(total_quantity: int) -> int:
    """
    Рассчитывает скидку партнёра по суммарному объёму продаж.
    """
    if total_quantity < 10_000:
        return 0
    elif total_quantity < 50_000:
        return 5
    elif total_quantity < 300_000:
        return 10
    else:
        return 15


def get_partner_total_quantity(partner_id: int) -> int:
    from db.database import get_connection
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT COALESCE(SUM(quantity), 0) AS total
        FROM partner_products
        WHERE partner_id = %s
    """, (partner_id,))
    result = cur.fetchone()
    cur.close()
    conn.close()
    return int(result["total"])


def get_partner_discount(partner_id: int) -> int:
    total = get_partner_total_quantity(partner_id)
    return calculate_discount(total)
