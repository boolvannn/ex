import pandas as pd
from db.database import get_connection


def import_all(base_path="data"):
    import_product_types(f"{base_path}/Product_type_import.xlsx")
    import_material_types(f"{base_path}/Material_type_import.xlsx")
    import_partners(f"{base_path}/Partners_import.xlsx")
    import_products(f"{base_path}/Products_import.xlsx")
    import_partner_products(f"{base_path}/Partner_products_import.xlsx")


def import_product_types(path):
    df = pd.read_excel(path)
    conn = get_connection()
    cur = conn.cursor()
    for _, row in df.iterrows():
        cur.execute("""
            INSERT INTO product_types (name, coefficient)
            VALUES (%s, %s)
            ON CONFLICT (name) DO UPDATE SET coefficient = EXCLUDED.coefficient
        """, (row.iloc[0], float(row.iloc[1])))
    conn.commit()
    cur.close()
    conn.close()


def import_material_types(path):
    df = pd.read_excel(path)
    conn = get_connection()
    cur = conn.cursor()
    for _, row in df.iterrows():
        cur.execute("""
            INSERT INTO material_types (name, defect_percent)
            VALUES (%s, %s)
            ON CONFLICT (name) DO UPDATE SET defect_percent = EXCLUDED.defect_percent
        """, (row.iloc[0], float(row.iloc[1])))
    conn.commit()
    cur.close()
    conn.close()


def import_partners(path):
    df = pd.read_excel(path)
    conn = get_connection()
    cur = conn.cursor()
    for _, row in df.iterrows():
        cur.execute("""
            INSERT INTO partners (partner_type, name, director, email, phone, legal_address, inn, rating)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            ON CONFLICT (name) DO UPDATE SET
                partner_type = EXCLUDED.partner_type,
                director = EXCLUDED.director,
                email = EXCLUDED.email,
                phone = EXCLUDED.phone,
                legal_address = EXCLUDED.legal_address,
                inn = EXCLUDED.inn,
                rating = EXCLUDED.rating
        """, (
            str(row.iloc[0]), str(row.iloc[1]), str(row.iloc[2]),
            str(row.iloc[3]), str(row.iloc[4]), str(row.iloc[5]),
            str(row.iloc[6]), int(row.iloc[7])
        ))
    conn.commit()
    cur.close()
    conn.close()


def import_products(path):
    df = pd.read_excel(path)
    conn = get_connection()
    cur = conn.cursor()
    for _, row in df.iterrows():
        cur.execute("SELECT id FROM product_types WHERE name = %s", (str(row.iloc[0]),))
        pt = cur.fetchone()
        pt_id = pt["id"] if pt else None
        cur.execute("""
            INSERT INTO products (product_type_id, name, article, min_price)
            VALUES (%s, %s, %s, %s)
            ON CONFLICT (name) DO UPDATE SET
                product_type_id = EXCLUDED.product_type_id,
                article = EXCLUDED.article,
                min_price = EXCLUDED.min_price
        """, (pt_id, str(row.iloc[1]), int(row.iloc[2]), float(row.iloc[3])))
    conn.commit()
    cur.close()
    conn.close()


def import_partner_products(path):
    df = pd.read_excel(path)
    conn = get_connection()
    cur = conn.cursor()
    for _, row in df.iterrows():
        cur.execute("SELECT id FROM products WHERE name = %s", (str(row.iloc[0]),))
        prod = cur.fetchone()
        cur.execute("SELECT id FROM partners WHERE name = %s", (str(row.iloc[1]),))
        part = cur.fetchone()
        if prod and part:
            cur.execute("""
                INSERT INTO partner_products (product_id, partner_id, quantity, sale_date)
                VALUES (%s, %s, %s, %s)
            """, (prod["id"], part["id"], int(row.iloc[2]), row.iloc[3]))
    conn.commit()
    cur.close()
    conn.close()
