import psycopg2
from psycopg2.extras import RealDictCursor


DB_CONFIG = {
    "host": "localhost",
    "port": 5432,
    "database": "master_pol",
    "user": "postgres",
    "password": "postgres"
}


def get_connection():
    return psycopg2.connect(**DB_CONFIG, cursor_factory=RealDictCursor)


def init_db():
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("""
        CREATE TABLE IF NOT EXISTS product_types (
            id SERIAL PRIMARY KEY,
            name VARCHAR(255) NOT NULL UNIQUE,
            coefficient NUMERIC(10, 4) NOT NULL
        );

        CREATE TABLE IF NOT EXISTS material_types (
            id SERIAL PRIMARY KEY,
            name VARCHAR(255) NOT NULL UNIQUE,
            defect_percent NUMERIC(10, 4) NOT NULL
        );

        CREATE TABLE IF NOT EXISTS partners (
            id SERIAL PRIMARY KEY,
            partner_type VARCHAR(50),
            name VARCHAR(255) NOT NULL UNIQUE,
            director VARCHAR(255),
            email VARCHAR(255),
            phone VARCHAR(100),
            legal_address TEXT,
            inn VARCHAR(20),
            rating INTEGER DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS products (
            id SERIAL PRIMARY KEY,
            product_type_id INTEGER REFERENCES product_types(id),
            name VARCHAR(500) NOT NULL UNIQUE,
            article INTEGER,
            min_price NUMERIC(12, 2)
        );

        CREATE TABLE IF NOT EXISTS partner_products (
            id SERIAL PRIMARY KEY,
            product_id INTEGER REFERENCES products(id),
            partner_id INTEGER REFERENCES partners(id),
            quantity INTEGER,
            sale_date DATE
        );
    """)

    conn.commit()
    cur.close()
    conn.close()
