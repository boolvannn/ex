# Модуль подключения к базе данных PostgreSQL
import psycopg2
from psycopg2.extras import RealDictCursor

# Настройки подключения — измените под свои данные
DB = {
    "host": "localhost",
    "port": 5432,
    "database": "master_pol",
    "user": "postgres",
    "password": "postgres"
}


def get_conn():
    """Возвращает соединение с БД."""
    return psycopg2.connect(**DB, cursor_factory=RealDictCursor)


def fetch_all(sql, params=()):
    """Выполняет SELECT и возвращает все строки."""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(sql, params)
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return rows


def execute(sql, params=()):
    """Выполняет INSERT / UPDATE / DELETE."""
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(sql, params)
    conn.commit()
    cur.close()
    conn.close()
