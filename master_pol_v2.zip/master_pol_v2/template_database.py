# ════════════════════════════════════════════════════════════════
#  ШАБЛОН ПРОЕКТА — адаптируй под свою предметную область
#  Файл: database.py
#  Назначение: подключение к PostgreSQL и вспомогательные функции
# ════════════════════════════════════════════════════════════════

import psycopg2
from psycopg2.extras import RealDictCursor

# TODO: измени название базы данных, логин и пароль
DB = {
    "host":     "localhost",
    "port":     5432,
    "database": "ИМЯ_БАЗЫ",   # <- сюда название БД
    "user":     "postgres",
    "password": "postgres"
}


def get_conn():
    """Возвращает соединение с БД."""
    return psycopg2.connect(**DB, cursor_factory=RealDictCursor)


def fetch_all(sql, params=()):
    """
    Выполняет SELECT-запрос и возвращает список строк-словарей.
    Пример вызова: fetch_all("SELECT * FROM clients WHERE city = %s", ("Москва",))
    """
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(sql, params)
    rows = cur.fetchall()
    cur.close()
    conn.close()
    return rows


def execute(sql, params=()):
    """
    Выполняет INSERT / UPDATE / DELETE.
    Пример вызова: execute("INSERT INTO clients (name) VALUES (%s)", ("Иван",))
    """
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(sql, params)
    conn.commit()
    cur.close()
    conn.close()
