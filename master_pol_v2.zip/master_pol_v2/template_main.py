# ════════════════════════════════════════════════════════════════
#  ШАБЛОН ГЛАВНОГО ФАЙЛА ПРИЛОЖЕНИЯ
#  Файл: main.py
#  Инструкция:
#  1. Найди все комментарии с пометкой TODO
#  2. Замени примеры под свою предметную область
#  3. Добавь нужные поля в форму
#  4. Положи logo.png и logo.ico рядом с этим файлом
# ════════════════════════════════════════════════════════════════

import tkinter as tk
from tkinter import ttk, messagebox
from database import fetch_all, execute  # наш модуль БД

# ──── Цвета (измени под руководство по стилю своего задания) ────
WHITE = "#FFFFFF"    # TODO: основной фон
BEIGE = "#F4E8D3"    # TODO: дополнительный фон
GREEN = "#67BA80"    # TODO: акцентный цвет
FONT  = "Segoe UI"   # шрифт по руководству по стилю


# ════════════════════════════════════════════════════════════════
#  ВСПОМОГАТЕЛЬНАЯ ФУНКЦИЯ — пример расчёта значения по таблице
#  TODO: адаптируй логику под своё задание
#        (скидка, категория, надбавка и т.д.)
# ════════════════════════════════════════════════════════════════
def calculate_value(record_id):
    """
    Пример: считает скидку по объёму продаж.
    TODO: замени SQL и пороговые значения под свою задачу.
    """
    rows = fetch_all(
        # TODO: замени на свой запрос
        "SELECT COALESCE(SUM(quantity), 0) AS total FROM sales WHERE client_id = %s",
        (record_id,)
    )
    total = int(rows[0]["total"])

    # TODO: замени пороги и возвращаемые значения
    if total < 10_000:
        return 0
    elif total < 50_000:
        return 5
    elif total < 300_000:
        return 10
    else:
        return 15


# ════════════════════════════════════════════════════════════════
#  ОКНО 1: Главная форма — список записей
#  TODO: переименуй класс, измени заголовок, столбцы таблицы
# ════════════════════════════════════════════════════════════════
class MainListWindow(tk.Tk):
    def __init__(self):
        super().__init__()

        # TODO: измени заголовок окна
        self.title("Название приложения — Список объектов")
        self.geometry("900x500")
        self.configure(bg=WHITE)

        # Иконка приложения (файл logo.ico должен лежать рядом)
        try:
            self.iconbitmap("logo.ico")
        except Exception:
            pass  # если файла нет — просто пропускаем без ошибки

        self._build_ui()     # строим интерфейс
        self.load_records()  # загружаем данные из БД

    def _build_ui(self):
        """Создаёт все визуальные элементы главного окна."""

        # ── Верхняя зелёная панель с логотипом ──
        top_panel = tk.Frame(self, bg=GREEN, pady=8)
        top_panel.pack(fill="x")

        # Логотип (файл logo.png должен лежать рядом с main.py)
        try:
            from PIL import Image, ImageTk
            img = Image.open("logo.png").resize((40, 40))  # размер логотипа
            self._logo = ImageTk.PhotoImage(img)
            tk.Label(top_panel, image=self._logo, bg=GREEN).pack(side="left", padx=12)
        except Exception:
            pass  # Pillow не установлен или файл не найден — продолжаем без логотипа

        # TODO: измени текст заголовка
        tk.Label(top_panel, text="Список объектов", font=(FONT, 16, "bold"),
                 bg=GREEN, fg=WHITE).pack(side="left")

        # Кнопка добавления новой записи
        tk.Button(top_panel, text="+ Добавить", font=(FONT, 10),
                  bg=WHITE, fg=GREEN, relief="flat", padx=10,
                  command=self.open_add_form).pack(side="right", padx=12)

        # ── Таблица (Treeview) ──
        table_frame = tk.Frame(self, bg=WHITE)
        table_frame.pack(fill="both", expand=True, padx=16, pady=10)

        # TODO: замени названия столбцов на свои
        # Формат: ("ключ_столбца", "Заголовок", ширина_в_пикселях)
        columns_config = [
            ("col1", "Поле 1",   150),
            ("col2", "Поле 2",   200),
            ("col3", "Поле 3",   150),
            ("col4", "Значение",  90),
        ]

        col_keys = [c[0] for c in columns_config]
        self.table = ttk.Treeview(table_frame, columns=col_keys,
                                  show="headings", height=18)

        for key, label, width in columns_config:
            self.table.heading(key, text=label)
            self.table.column(key, width=width, anchor="w")

        # Стиль таблицы
        style = ttk.Style()
        style.configure("Treeview", font=(FONT, 10), rowheight=28)
        style.configure("Treeview.Heading", font=(FONT, 10, "bold"),
                         background=BEIGE)

        # Полоса прокрутки
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical",
                                  command=self.table.yview)
        self.table.configure(yscrollcommand=scrollbar.set)
        self.table.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        # Двойной клик по строке — открыть форму редактирования
        self.table.bind("<Double-1>", self.open_edit_form)

        # Подсказка пользователю внизу окна
        tk.Label(self, text="Двойной клик по строке — редактировать",
                 font=(FONT, 9), bg=WHITE, fg="gray").pack(pady=(0, 6))

    def load_records(self):
        """
        Загружает данные из БД и заполняет таблицу.
        TODO: замени SQL-запрос на свой.
        """
        # Очищаем таблицу перед повторной загрузкой
        for row in self.table.get_children():
            self.table.delete(row)

        # TODO: замени на SELECT из своей таблицы
        records = fetch_all("SELECT * FROM your_table ORDER BY name")

        for r in records:
            # TODO: замени вычисление на своё (или убери вовсе)
            value = calculate_value(r["id"])

            # TODO: замени r["field1"] и т.д. на свои поля
            self.table.insert("", "end", iid=r["id"], values=(
                r["field1"],
                r["field2"],
                r["field3"],
                f"{value}%",  # TODO: формат вывода
            ))

    def open_add_form(self):
        """Открывает форму для добавления новой записи."""
        RecordFormWindow(self, record_id=None)

    def open_edit_form(self, event):
        """Открывает форму редактирования выбранной записи."""
        selected = self.table.focus()
        if selected:
            RecordFormWindow(self, record_id=int(selected))


# ════════════════════════════════════════════════════════════════
#  ОКНО 2: Форма добавления / редактирования записи
#  TODO: переименуй класс, добавь/удали поля под свою задачу
# ════════════════════════════════════════════════════════════════
class RecordFormWindow(tk.Toplevel):
    def __init__(self, parent, record_id=None):
        super().__init__(parent)
        self.parent = parent          # нужен для обновления списка после сохранения
        self.record_id = record_id    # None = добавление, число = редактирование

        # Заголовок зависит от режима (добавление или редактирование)
        mode = "Редактировать" if record_id else "Добавить"
        # TODO: замени «объект» на своё слово (партнёр, клиент, товар и т.д.)
        self.title(f"Название приложения — {mode} объект")

        self.geometry("460x420")
        self.resizable(False, False)
        self.configure(bg=WHITE)
        self.grab_set()  # делаем окно модальным (блокируем главное)

        self._build_form()

        # При редактировании — подгружаем текущие данные в поля
        if record_id:
            self._load_data()

    def _build_form(self):
        """Создаёт поля формы."""

        # Заголовок формы
        mode = "Редактирование" if self.record_id else "Добавление"
        tk.Label(self, text=f"{mode} объекта",   # TODO: замени слово
                 font=(FONT, 14, "bold"), bg=WHITE, fg="#333").pack(pady=(14, 6))

        # Фоновый контейнер для полей
        form = tk.Frame(self, bg=BEIGE, padx=20, pady=14)
        form.pack(fill="both", expand=True, padx=20, pady=(0, 8))
        form.columnconfigure(1, weight=1)

        # ── Создаём переменные для каждого поля ──
        # TODO: добавь/удали переменные под свои поля
        self.v_field1 = tk.StringVar()   # TODO: переименуй
        self.v_field2 = tk.StringVar()   # TODO: переименуй
        self.v_field3 = tk.StringVar()   # TODO: переименуй
        self.v_number = tk.StringVar(value="0")  # числовое поле

        # Вспомогательная функция — создаёт Label + Entry в одну строку
        def add_entry(label_text, var, row):
            tk.Label(form, text=label_text, font=(FONT, 10),
                     bg=BEIGE, anchor="w").grid(row=row, column=0,
                                                sticky="w", pady=4)
            tk.Entry(form, textvariable=var, width=28, font=(FONT, 10),
                     relief="flat", bg=WHITE).grid(row=row, column=1,
                                                    sticky="ew", padx=(10, 0), pady=4)

        # Вспомогательная функция — создаёт Label + Combobox (выпадающий список)
        def add_combobox(label_text, var, values, row):
            tk.Label(form, text=label_text, font=(FONT, 10),
                     bg=BEIGE, anchor="w").grid(row=row, column=0,
                                                sticky="w", pady=4)
            ttk.Combobox(form, textvariable=var, values=values,
                         state="readonly", width=26,
                         font=(FONT, 10)).grid(row=row, column=1,
                                               sticky="ew", padx=(10, 0), pady=4)

        # TODO: добавь свои поля, используя add_entry или add_combobox
        add_entry("Поле 1 *",    self.v_field1, 0)   # * = обязательное
        add_entry("Поле 2",      self.v_field2, 1)
        add_combobox("Тип",      self.v_field3,
                     ["Вариант А", "Вариант Б", "Вариант В"], 2)  # TODO: свои варианты

        # Числовое поле (например, рейтинг, количество)
        tk.Label(form, text="Число (≥ 0)", font=(FONT, 10),
                 bg=BEIGE, anchor="w").grid(row=3, column=0, sticky="w", pady=4)
        tk.Spinbox(form, textvariable=self.v_number, from_=0, to=9999,
                   width=8, font=(FONT, 10), relief="flat",
                   bg=WHITE).grid(row=3, column=1, sticky="w", padx=(10, 0))

        # ── Кнопки ──
        btn_frame = tk.Frame(self, bg=WHITE)
        btn_frame.pack(fill="x", padx=20, pady=10)

        tk.Button(btn_frame, text="Сохранить", font=(FONT, 10, "bold"),
                  bg=GREEN, fg=WHITE, relief="flat", padx=16, pady=6,
                  command=self.save).pack(side="right")

        tk.Button(btn_frame, text="Отмена", font=(FONT, 10),
                  bg=BEIGE, relief="flat", padx=12, pady=6,
                  command=self.destroy).pack(side="right", padx=(0, 8))

        # Кнопка удаления — только при редактировании
        if self.record_id:
            tk.Button(btn_frame, text="Удалить", font=(FONT, 10),
                      bg="#E53935", fg=WHITE, relief="flat", padx=12, pady=6,
                      command=self.delete).pack(side="left")

    def _load_data(self):
        """
        Загружает данные записи из БД в поля формы.
        TODO: замени SQL и имена полей на свои.
        """
        # TODO: замени your_table на имя своей таблицы
        rows = fetch_all("SELECT * FROM your_table WHERE id = %s", (self.record_id,))
        if not rows:
            return
        r = rows[0]

        # TODO: замени имена полей (r["field1"] и т.д.) на свои
        self.v_field1.set(r["field1"] or "")
        self.v_field2.set(r["field2"] or "")
        self.v_field3.set(r["field3"] or "")
        self.v_number.set(str(r["number_field"] or 0))

    def save(self):
        """
        Валидация полей и сохранение данных в БД.
        TODO: добавь валидацию своих обязательных полей.
        """
        # Проверяем обязательное поле
        field1 = self.v_field1.get().strip()
        if not field1:
            # Показываем ошибку — информативное сообщение с пиктограммой ошибки
            messagebox.showwarning("Ошибка заполнения",
                                   "Поле «Поле 1» обязательно для заполнения.\n"
                                   "Введите значение и попробуйте снова.",
                                   parent=self)
            return

        # Проверяем числовое поле
        try:
            number = int(self.v_number.get())
            if number < 0:
                raise ValueError("Число отрицательное")
        except ValueError:
            messagebox.showwarning("Ошибка заполнения",
                                   "Поле «Число» должно быть целым неотрицательным числом.",
                                   parent=self)
            return

        # Сохраняем — UPDATE или INSERT в зависимости от режима
        if self.record_id:
            # TODO: замени SQL и параметры на свои поля
            execute("""
                UPDATE your_table
                SET field1 = %s, field2 = %s, field3 = %s, number_field = %s
                WHERE id = %s
            """, (field1, self.v_field2.get(), self.v_field3.get(),
                  number, self.record_id))
            messagebox.showinfo("Успешно", "Данные успешно обновлены.", parent=self)
        else:
            # TODO: замени SQL и параметры на свои поля
            execute("""
                INSERT INTO your_table (field1, field2, field3, number_field)
                VALUES (%s, %s, %s, %s)
            """, (field1, self.v_field2.get(), self.v_field3.get(), number))
            messagebox.showinfo("Успешно", "Запись успешно добавлена.", parent=self)

        # Обновляем список в главном окне
        self.parent.load_records()
        self.destroy()  # закрываем форму

    def delete(self):
        """
        Удаление записи с обязательным подтверждением.
        TODO: если есть связанные таблицы — удали их данные первыми.
        """
        # Предупреждаем пользователя о необратимости
        confirmed = messagebox.askyesno(
            "Подтверждение удаления",
            "Вы уверены, что хотите удалить эту запись?\n"
            "Это действие нельзя отменить.",
            parent=self
        )
        if not confirmed:
            return

        # TODO: если есть связанные таблицы — раскомментируй и замени:
        # execute("DELETE FROM related_table WHERE parent_id = %s", (self.record_id,))

        # TODO: замени your_table на имя своей таблицы
        execute("DELETE FROM your_table WHERE id = %s", (self.record_id,))

        messagebox.showinfo("Удалено", "Запись удалена.", parent=self)
        self.parent.load_records()  # обновляем список
        self.destroy()


# ════════════════════════════════════════════════════════════════
#  ТОЧКА ВХОДА — запуск приложения
# ════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    try:
        app = MainListWindow()
        app.mainloop()
    except Exception as error:
        # Если что-то пошло не так при старте — показываем понятную ошибку
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()  # прячем пустое окно
        messagebox.showerror("Ошибка запуска",
                             f"Приложение не смогло запуститься:\n{error}\n\n"
                             "Проверьте подключение к БД в файле database.py")
        root.destroy()
