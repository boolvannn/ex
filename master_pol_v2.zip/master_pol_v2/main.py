# Главный файл приложения «Мастер пол»
# Запускать: python main.py

import tkinter as tk
from tkinter import ttk, messagebox
from database import fetch_all, execute

# ───────── Цвета по руководству по стилю ─────────
WHITE  = "#FFFFFF"   # основной фон
BEIGE  = "#F4E8D3"   # дополнительный фон
GREEN  = "#67BA80"   # акцент
FONT   = "Segoe UI"


# ══════════════════════════════════════════════════════
#  ВСПОМОГАТЕЛЬНАЯ ФУНКЦИЯ: расчёт скидки партнёра
# ══════════════════════════════════════════════════════
def get_discount(partner_id):
    """Считает суммарный объём продаж и возвращает скидку в %."""
    rows = fetch_all(
        "SELECT COALESCE(SUM(quantity), 0) AS total FROM partner_products WHERE partner_id = %s",
        (partner_id,)
    )
    total = int(rows[0]["total"])
    if total < 10_000:
        return 0
    elif total < 50_000:
        return 5
    elif total < 300_000:
        return 10
    else:
        return 15


# ══════════════════════════════════════════════════════
#  ОКНО 1: Список партнёров (главная форма)
# ══════════════════════════════════════════════════════
class PartnersListWindow(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Мастер пол — Партнёры")
        self.geometry("900x500")
        self.configure(bg=WHITE)

        # Попытка установить иконку приложения
        try:
            self.iconbitmap("logo.ico")
        except Exception:
            pass

        self._build()
        self.load_partners()

    def _build(self):
        # ── Верхняя панель с логотипом и заголовком ──
        top = tk.Frame(self, bg=GREEN, pady=8)
        top.pack(fill="x")

        # Логотип (если файл есть рядом с main.py)
        try:
            from PIL import Image, ImageTk
            img = Image.open("logo.png").resize((40, 40))
            self._logo = ImageTk.PhotoImage(img)
            tk.Label(top, image=self._logo, bg=GREEN).pack(side="left", padx=12)
        except Exception:
            pass  # если Pillow не установлен — просто пропускаем

        tk.Label(top, text="Партнёры", font=(FONT, 16, "bold"),
                 bg=GREEN, fg=WHITE).pack(side="left")

        # Кнопка «Добавить»
        tk.Button(top, text="+ Добавить", font=(FONT, 10),
                  bg=WHITE, fg=GREEN, relief="flat", padx=10,
                  command=self.open_add_form).pack(side="right", padx=12)

        # ── Таблица партнёров ──
        frame = tk.Frame(self, bg=WHITE)
        frame.pack(fill="both", expand=True, padx=16, pady=10)

        cols = ("type", "name", "director", "phone", "rating", "discount")
        self.table = ttk.Treeview(frame, columns=cols, show="headings", height=18)

        # Заголовки и ширины столбцов
        for col, label, w in [
            ("type",     "Тип",        80),
            ("name",     "Партнёр",   220),
            ("director", "Директор",  180),
            ("phone",    "Телефон",   130),
            ("rating",   "Рейтинг",    70),
            ("discount", "Скидка",     70),
        ]:
            self.table.heading(col, text=label)
            self.table.column(col, width=w, anchor="w")

        # Стиль таблицы
        style = ttk.Style()
        style.configure("Treeview", font=(FONT, 10), rowheight=28)
        style.configure("Treeview.Heading", font=(FONT, 10, "bold"), background=BEIGE)

        sb = ttk.Scrollbar(frame, orient="vertical", command=self.table.yview)
        self.table.configure(yscrollcommand=sb.set)
        self.table.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

        # Двойной клик — открыть форму редактирования
        self.table.bind("<Double-1>", self.open_edit_form)

        # ── Строка подсказки ──
        tk.Label(self, text="Двойной клик по строке — редактировать партнёра",
                 font=(FONT, 9), bg=WHITE, fg="gray").pack(pady=(0, 6))

    def load_partners(self):
        """Загружает партнёров из БД и заполняет таблицу."""
        # Очищаем таблицу перед обновлением
        for row in self.table.get_children():
            self.table.delete(row)

        partners = fetch_all("SELECT * FROM partners ORDER BY name")
        for p in partners:
            discount = get_discount(p["id"])
            self.table.insert("", "end", iid=p["id"], values=(
                p["partner_type"], p["name"], p["director"],
                p["phone"], p["rating"], f"{discount}%"
            ))

    def open_add_form(self):
        """Открывает форму добавления нового партнёра."""
        PartnerFormWindow(self, partner_id=None)

    def open_edit_form(self, event):
        """Открывает форму редактирования выбранного партнёра."""
        selected = self.table.focus()
        if selected:
            PartnerFormWindow(self, partner_id=int(selected))


# ══════════════════════════════════════════════════════
#  ОКНО 2: Форма добавления / редактирования партнёра
# ══════════════════════════════════════════════════════
class PartnerFormWindow(tk.Toplevel):
    def __init__(self, parent, partner_id=None):
        super().__init__(parent)
        self.parent = parent          # ссылка на главное окно для обновления
        self.partner_id = partner_id  # None = добавление, иначе = редактирование

        title = "Редактировать партнёра" if partner_id else "Добавить партнёра"
        self.title(f"Мастер пол — {title}")
        self.geometry("480x460")
        self.resizable(False, False)
        self.configure(bg=WHITE)
        self.grab_set()  # блокируем главное окно пока форма открыта

        self._build()

        # Если редактирование — загружаем данные в поля
        if partner_id:
            self._load_data()

    def _build(self):
        # Заголовок формы
        tk.Label(self, text=self.title().split("—")[1].strip(),
                 font=(FONT, 14, "bold"), bg=WHITE, fg="#333").pack(pady=(14, 4))

        # Контейнер полей
        form = tk.Frame(self, bg=BEIGE, padx=20, pady=16)
        form.pack(fill="both", expand=True, padx=20, pady=8)

        # Создаём переменные для каждого поля
        self.v_type     = tk.StringVar()
        self.v_name     = tk.StringVar()
        self.v_director = tk.StringVar()
        self.v_email    = tk.StringVar()
        self.v_phone    = tk.StringVar()
        self.v_address  = tk.StringVar()
        self.v_rating   = tk.StringVar(value="0")

        # Вспомогательная функция создания поля
        def add_field(label, var, row, widget_type="entry"):
            tk.Label(form, text=label, font=(FONT, 10), bg=BEIGE,
                     anchor="w").grid(row=row, column=0, sticky="w", pady=4)
            if widget_type == "combobox":
                w = ttk.Combobox(form, textvariable=var,
                                 values=["ЗАО", "ООО", "ПАО", "ОАО", "ИП"],
                                 state="readonly", width=28, font=(FONT, 10))
            else:
                w = tk.Entry(form, textvariable=var, width=30,
                             font=(FONT, 10), relief="flat", bg=WHITE)
            w.grid(row=row, column=1, sticky="ew", padx=(10, 0), pady=4)
            return w

        add_field("Тип партнёра",   self.v_type,     0, "combobox")
        add_field("Наименование *", self.v_name,     1)
        add_field("Директор",       self.v_director, 2)
        add_field("Email",          self.v_email,    3)
        add_field("Телефон",        self.v_phone,    4)
        add_field("Адрес",          self.v_address,  5)

        # Рейтинг — только целое неотрицательное число
        tk.Label(form, text="Рейтинг", font=(FONT, 10),
                 bg=BEIGE, anchor="w").grid(row=6, column=0, sticky="w", pady=4)
        tk.Spinbox(form, textvariable=self.v_rating, from_=0, to=10,
                   width=6, font=(FONT, 10), relief="flat",
                   bg=WHITE).grid(row=6, column=1, sticky="w", padx=(10, 0))

        form.columnconfigure(1, weight=1)

        # Кнопки действий
        btn_frame = tk.Frame(self, bg=WHITE)
        btn_frame.pack(fill="x", padx=20, pady=10)

        tk.Button(btn_frame, text="Сохранить", font=(FONT, 10, "bold"),
                  bg=GREEN, fg=WHITE, relief="flat", padx=16, pady=6,
                  command=self.save).pack(side="right")

        tk.Button(btn_frame, text="Отмена", font=(FONT, 10),
                  bg=BEIGE, relief="flat", padx=12, pady=6,
                  command=self.destroy).pack(side="right", padx=(0, 8))

        # Кнопка «Удалить» — только при редактировании
        if self.partner_id:
            tk.Button(btn_frame, text="Удалить", font=(FONT, 10),
                      bg="#E53935", fg=WHITE, relief="flat", padx=12, pady=6,
                      command=self.delete).pack(side="left")

    def _load_data(self):
        """Загружает данные партнёра из БД в поля формы."""
        rows = fetch_all("SELECT * FROM partners WHERE id = %s", (self.partner_id,))
        if not rows:
            return
        p = rows[0]
        self.v_type.set(p["partner_type"] or "")
        self.v_name.set(p["name"] or "")
        self.v_director.set(p["director"] or "")
        self.v_email.set(p["email"] or "")
        self.v_phone.set(p["phone"] or "")
        self.v_address.set(p["legal_address"] or "")
        self.v_rating.set(str(p["rating"] or 0))

    def save(self):
        """Валидация и сохранение данных партнёра."""
        name = self.v_name.get().strip()
        if not name:
            messagebox.showwarning("Ошибка", "Поле «Наименование» обязательно для заполнения.",
                                   parent=self)
            return

        # Проверяем что рейтинг — целое неотрицательное число
        try:
            rating = int(self.v_rating.get())
            if rating < 0:
                raise ValueError
        except ValueError:
            messagebox.showwarning("Ошибка",
                                   "Рейтинг должен быть целым неотрицательным числом (0 и выше).",
                                   parent=self)
            return

        if self.partner_id:
            # Обновляем существующего партнёра
            execute("""
                UPDATE partners SET partner_type=%s, name=%s, director=%s,
                    email=%s, phone=%s, legal_address=%s, rating=%s
                WHERE id=%s
            """, (self.v_type.get(), name, self.v_director.get(),
                  self.v_email.get(), self.v_phone.get(),
                  self.v_address.get(), rating, self.partner_id))
            messagebox.showinfo("Готово", "Данные партнёра обновлены.", parent=self)
        else:
            # Добавляем нового партнёра
            execute("""
                INSERT INTO partners (partner_type, name, director, email, phone, legal_address, rating)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
            """, (self.v_type.get(), name, self.v_director.get(),
                  self.v_email.get(), self.v_phone.get(),
                  self.v_address.get(), rating))
            messagebox.showinfo("Готово", "Партнёр успешно добавлен.", parent=self)

        # Обновляем список в главном окне
        self.parent.load_partners()
        self.destroy()

    def delete(self):
        """Удаление партнёра с подтверждением."""
        confirm = messagebox.askyesno(
            "Подтверждение удаления",
            f"Вы уверены, что хотите удалить партнёра?\nЭто действие необратимо.",
            parent=self
        )
        if not confirm:
            return

        # Сначала удаляем связанные продажи, потом самого партнёра
        execute("DELETE FROM partner_products WHERE partner_id = %s", (self.partner_id,))
        execute("DELETE FROM partners WHERE id = %s", (self.partner_id,))

        messagebox.showinfo("Удалено", "Партнёр удалён.", parent=self)
        self.parent.load_partners()
        self.destroy()


# ══════════════════════════════════════════════════════
#  ТОЧКА ВХОДА
# ══════════════════════════════════════════════════════
if __name__ == "__main__":
    try:
        app = PartnersListWindow()
        app.mainloop()
    except Exception as e:
        # Если БД недоступна — показываем понятную ошибку
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("Ошибка подключения к БД",
                             f"Не удалось подключиться к PostgreSQL:\n{e}\n\n"
                             "Проверьте настройки в файле database.py")
        root.destroy()
